"use client"

import { useState } from "react"
import Link from "next/link"

export default function GuestModePage() {
  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-7xl space-y-8">
          <div className="flex items-center justify-between">
                Back to Home
              
          </div>

      </div>
    </div>
  )
}
