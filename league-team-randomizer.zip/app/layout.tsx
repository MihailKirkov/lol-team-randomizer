export const metadata: Metadata = {
  // <CHANGE> Updated metadata for LoL Team Randomizer
  title: "LoL Team Randomizer - Generate Balanced League of Legends Teams",
  description:
    "Smart team generator for League of Legends. Create balanced teams with role assignments, track statistics, and manage your roster.",,
  // ... existing code ...
    generator: 'v0.app'
}
// ... existing code ...


import './globals.css'